import gui.LoginFrame;


public class UserLoginGUI {
    public static void main(String[] args) {
        new LoginFrame(); 
    }
}

