package models;


public interface AdminAccess {
 void openAdminPanel();
}
